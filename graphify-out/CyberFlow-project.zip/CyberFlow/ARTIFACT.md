# CyberFlow — артефакт проекта

Снимок ветки dev от 21 ноября 2026 г. Код и граф соответствуют коммиту ef47aad.

## Архитектура

- **frontend/** — визуальный редактор React Flow, библиотека шаблонов, инспектор запусков и управление учётными данными.
- **backend/app/api/** — FastAPI, сценарии, CI-webhook, шаблоны и SSE.
- **backend/app/workflows/** — очередь PostgreSQL, выполнение графа и проверка порога CI.
- **backend/app/analyzers/** — анализ исходников и зависимостей учебных проектов.
- **backend/app/notifications/** — очередь доставки отчётов через Telegram и SMTP. Её обрабатывает отдельный воркер.
- **backend/migrations/** — схема данных, включая шифрованные учётные данные и уведомления об изменениях статусов.

Инструкции по запуску есть в [README бэкенда](backend/README.md) и [README фронтенда](frontend/README.md).

## Граф проекта

[Интерактивный граф](graphify-out/graph.html) · [Отчёт Graphify](graphify-out/GRAPH_REPORT.md) · [Граф JSON](graphify-out/graph.json)

Граф построен локально командой **graphify update .** Он содержит 899 узлов и 2882 связей. Часть связей Graphify помечает как предполагаемые. Файл **MANIFEST.sha256** содержит контрольные суммы.
